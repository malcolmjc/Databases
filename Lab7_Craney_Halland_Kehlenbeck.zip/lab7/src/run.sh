#!/bin/sh
export LAB7_JDBC_URL=jdbc:mysql://db.labthreesixfive.com/dhalland?useSSL=true
export LAB7_JDBC_USER=dhalland
export LAB7_JDBC_PW=CSC365-F2019_011041468
javac *.java
java -classpath ./mysql-connector-java-8.0.16.jar:. Main
